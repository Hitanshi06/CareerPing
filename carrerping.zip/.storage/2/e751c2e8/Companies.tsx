import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Search, Building, MapPin, Calendar, Users, Star, Bell, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Companies() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');

  const companies = [
    {
      id: '1',
      name: 'Amazon Web Services',
      logo: '🟠',
      description: 'Cloud computing platform and services',
      verified: true,
      followers: 2450,
      upcomingEvents: 3,
      pastEvents: 12,
      categories: ['Tech Talks', 'Workshops'],
      location: 'Chicago, IL'
    },
    {
      id: '2',
      name: 'Accenture',
      logo: '🔷',
      description: 'Global professional services company',
      verified: true,
      followers: 1890,
      upcomingEvents: 2,
      pastEvents: 8,
      categories: ['Job Fairs', 'Workshops'],
      location: 'Chicago, IL'
    },
    {
      id: '3',
      name: 'Discover Financial',
      logo: '🟡',
      description: 'Digital banking and payment services',
      verified: true,
      followers: 1234,
      upcomingEvents: 1,
      pastEvents: 6,
      categories: ['Hackathons', 'Tech Talks'],
      location: 'Riverwoods, IL'
    },
    {
      id: '4',
      name: 'CME Group',
      logo: '🔵',
      description: 'Financial derivatives marketplace',
      verified: true,
      followers: 987,
      upcomingEvents: 2,
      pastEvents: 5,
      categories: ['Hackathons', 'Job Fairs'],
      location: 'Chicago, IL'
    },
    {
      id: '5',
      name: 'Northwestern University',
      logo: '🟣',
      description: 'Private research university',
      verified: true,
      followers: 3456,
      upcomingEvents: 4,
      pastEvents: 15,
      categories: ['Hackathons', 'Workshops', 'Tech Talks'],
      location: 'Evanston, IL'
    },
    {
      id: '6',
      name: 'TechStars Chicago',
      logo: '⭐',
      description: 'Startup accelerator and venture capital',
      verified: true,
      followers: 1567,
      upcomingEvents: 2,
      pastEvents: 9,
      categories: ['Job Fairs', 'Tech Talks'],
      location: 'Chicago, IL'
    }
  ];

  const filteredCompanies = companies.filter(company =>
    company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const categoryColors = {
    'Hackathons': 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    'Job Fairs': 'bg-green-500/20 text-green-300 border-green-500/30',
    'Tech Talks': 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    'Workshops': 'bg-orange-500/20 text-orange-300 border-orange-500/30'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white">
      {/* Header */}
      <div className="bg-slate-900/80 backdrop-blur-md border-b border-slate-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => navigate('/')}
                className="flex items-center text-slate-300 hover:text-white"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-white">Company Profiles</h1>
                <p className="text-sm text-slate-400">
                  {filteredCompanies.length} companies hosting events in Chicago
                </p>
              </div>
            </div>
            <Button onClick={() => navigate('/events')} className="bg-blue-600 hover:bg-blue-700">
              View All Events
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-2xl">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 h-5 w-5" />
            <Input
              placeholder="Search companies (e.g., Amazon, Accenture, Discover)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 py-4 text-lg bg-slate-800/50 border-slate-600 text-white placeholder-slate-400 focus:border-blue-500"
            />
          </div>
        </div>

        {/* Companies Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredCompanies.map((company) => (
            <Card key={company.id} className="border-0 shadow-xl bg-slate-800/50 border border-slate-700 hover:border-slate-600 transition-all duration-300 group">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-slate-700 rounded-lg flex items-center justify-center text-2xl">
                      {company.logo}
                    </div>
                    <div>
                      <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
                        {company.name}
                        {company.verified && (
                          <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs">
                            ✓ Verified
                          </Badge>
                        )}
                      </CardTitle>
                      <div className="flex items-center gap-1 text-sm text-slate-400 mt-1">
                        <MapPin className="h-3 w-3" />
                        {company.location}
                      </div>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="border-slate-600 text-slate-300 hover:text-white hover:border-slate-500">
                    <Bell className="h-4 w-4 mr-1" />
                    Follow
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-sm text-slate-300 leading-relaxed">
                  {company.description}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  {company.categories.map((category) => (
                    <Badge key={category} className={categoryColors[category as keyof typeof categoryColors]}>
                      {category}
                    </Badge>
                  ))}
                </div>
                
                <div className="grid grid-cols-3 gap-4 py-3 border-t border-slate-700">
                  <div className="text-center">
                    <div className="text-lg font-bold text-blue-400">{company.followers}</div>
                    <div className="text-xs text-slate-400">Followers</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-400">{company.upcomingEvents}</div>
                    <div className="text-xs text-slate-400">Upcoming</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-purple-400">{company.pastEvents}</div>
                    <div className="text-xs text-slate-400">Past Events</div>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                    <Calendar className="h-4 w-4 mr-1" />
                    View Events
                  </Button>
                  <Button size="sm" variant="outline" className="border-slate-600 text-slate-300 hover:text-white hover:border-slate-500">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredCompanies.length === 0 && (
          <div className="text-center py-12">
            <div className="text-slate-400 mb-4">
              <Building className="mx-auto h-12 w-12" />
            </div>
            <h3 className="text-lg font-medium text-white mb-2">No companies found</h3>
            <p className="text-slate-400 mb-4">
              Try adjusting your search criteria or check back later for new companies.
            </p>
            <Button 
              variant="outline" 
              onClick={() => setSearchTerm('')}
              className="border-slate-600 text-slate-300 hover:text-white hover:border-slate-500"
            >
              Clear Search
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}